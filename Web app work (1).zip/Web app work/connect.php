<?php
$con = mysqli_connect("localhost","root","","Webapp");
if (!$con) {
  echo 'connection aborted';
  # code...
}
if(!mysqli_select_db($con,'Userinfo')){
echo 'Data base not selected'
}
$Username = $_POST['username'];
$Password = $_POST['password'];
$Firstname = $_POST['Firstname'];
$Secondname = $_POST['Secondname'];
$Email = $_POST['Email'];
$Phoneno = $_POST['Phoneno'];
$sql = "INSERT INTO Userinfo (Username, Password) VALUES ('$Username','$Password')";
if (!mysqli_query($con,$sql)) {
  echo "Not inserted";
}
else {
echo 'Passed';
}
header("refresh:2;login.html")
?>
